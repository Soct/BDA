import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
// Classe Question
// Corentin Filoche
// Contient l'ensemble des questions des diff�rents TP
public class Question
{
	// **************************************************
	// TP1
	// **************************************************
	// Question 1
	// R�cup�rer les 10 premi�res lignes de la table FILM et les afficher
	public static void question1_1(Connection co) throws InterruptedException, IOException, SQLException
	{
		OutilsJDBC.afficherQuestion(1, 2);
		String maRequete = "SELECT * FROM ENS2004.FILM F WHERE rownum<=10";
		ResultSet monResultat = OutilsJDBC.exec1Requete(maRequete, co, 0);
		OutilsJDBC.afficherTout(monResultat);
	}
	// Question 2
	// Idem
	public static void question1_2(Connection co) throws InterruptedException, IOException, SQLException
	{
		OutilsJDBC.afficherQuestion(1, 2);
		String maRequete = "SELECT * FROM ENS2004.FILM F WHERE rownum<=10";
		ResultSet monResultat = OutilsJDBC.exec1Requete(maRequete, co, 0);
		OutilsJDBC.afficherTout(monResultat);
	}
	// Question 3
	// R�cup�rer les individus dont le nom est FONDA et les afficher
	public static void question1_3(Connection co) throws InterruptedException, IOException, SQLException
	{
		OutilsJDBC.afficherQuestion(1, 3);
		String maRequete2 = "SELECT * FROM ENS2004.INDIVIDU I WHERE I.NOMINDIVIDU='FONDA'";
		ResultSet monResultat2 = OutilsJDBC.exec1Requete(maRequete2, co, 0);
		OutilsJDBC.afficherTout(monResultat2);
	}
	// Question 4
	// Afficher le titre des films r�alis�s par Stephen Roberts
	public static void question1_4(Connection co) throws InterruptedException, IOException, SQLException
	{
		OutilsJDBC.afficherQuestion(1, 4);
		String maRequete2 = "SELECT * FROM ENS2004.INDIVIDU I, ENS2004.FILM F, ENS2004.ACTEUR A "
		                    + "WHERE I.NUMINDIVIDU=A.NUMINDIVIDU AND F.NUMFILM=A.NUMFILM "
		                    + "AND I.NOMINDIVIDU='ROBERTS' AND I.PRENOMINDIVIDU='STEPHEN'";
		ResultSet monResultat = OutilsJDBC.exec1Requete(maRequete2, co, 0);
		OutilsJDBC.afficherTout(monResultat);
	}
	// Question 5
	// Permet de demander une table et d'afficher les caract�ristiques
	// De celle-ci (Attributs, types, etc...)
	public static void question1_5(Connection co) throws InterruptedException, IOException, SQLException
	{
		OutilsJDBC.afficherQuestion(1, 5);
		// Saisie du nom de l'acteur
		System.out.println("Veuillez saisir votre acteur pr�f�r� ?");
		// Stockage du nom
		String nomActeurAsked = Saisie.chaine();
		// ON DOIT PRESENTER TOUS LES COUPLES PRENOMS/NOMS QUI ONT CE NOM
		// On recherche tous les pr�noms avec ce nom
		String maRequete3 = "SELECT I.PRENOMINDIVIDU FROM ENS2004.INDIVIDU I WHERE I.NOMINDIVIDU=UPPER('"
		                    + nomActeurAsked + "')";
		// On envoie la requ�te
		ResultSet monResultat3 = OutilsJDBC.exec1Requete(maRequete3, co, 1);
		// On regarde si on a au moins un r�sultat
		if (!monResultat3.next())
		{
			System.out.println("Il n'y a aucun acteur de ce nom dans la Base");
			System.exit(1);
		}
		// On recule le curseur d'un rang vu que next l'a avanc�
		monResultat3.previous();
		// On affiche tous les couples que l'on a trouv�
		int cpt = 1;
		// On efface l'affichage
		OutilsJDBC.clear();
		while (monResultat3.next())
		{
			System.out.print(cpt + ". ");
			System.out.print(monResultat3.getString(1) + " " + nomActeurAsked.toUpperCase());
			System.out.println();
			cpt++;
		}
		// On demande � l'user de choisir un acteur pr�cis parmi la liste qu'on lui propose
		System.out.println("Veuillez s�lectionner un acteur en entrant son num�ro");
		int numActeurAsked = Saisie.entier();
		System.out.println(cpt + "cpt");
		System.out.println(numActeurAsked + "numAc");
		// On v�rifie que le num�ro est correct
		while (!(numActeurAsked > 0 && numActeurAsked < cpt))
		{
			System.out.println("Il faut choisir un num�ro parmi ceux propos�s !");
			numActeurAsked = Saisie.entier();
		}
		// On place le curseur � la position N
		monResultat3.absolute(numActeurAsked);
		// On r�cup�re le pr�nom de l'acteur
		String prenomActeurAscked = monResultat3.getString(1);
		// On r�cup�re tous les films de cette acteur
		String maRequete4 = "SELECT F.TITRE FROM ENS2004.INDIVIDU I, ENS2004.FILM F, " + "ENS2004.ACTEUR A "
		                    + "WHERE I.NUMINDIVIDU=A.NUMINDIVIDU " + "AND F.NUMFILM = A.NUMFILM "
		                    + "AND I.NOMINDIVIDU=UPPER('" + nomActeurAsked
		                    + "') AND I.PRENOMINDIVIDU=UPPER('" + prenomActeurAscked + "')";
		// On envoie la requ�te
		ResultSet monResultat4 = OutilsJDBC.exec1Requete(maRequete4, co, 1);
		// On regarde si on a au moins un r�sultat
		if (!monResultat4.next())
		{
			System.out.println("Il n'y a aucun film pour cet acteur");
			System.exit(1);
		}
		// On recule le curseur d'un rang vu que next l'a avanc�
		monResultat4.previous();
		// On affiche les films avec les num�ros
		// On traite le r�sultat en attribuant un num�ro �
		// chaque film trouv�
		cpt = 1;
		while (monResultat4.next())
		{
			System.out.print(cpt + ". ");
			System.out.print(monResultat4.getString(1) + "\t");
			System.out.println();
			cpt++;
		}
		// On demande � l'utilisateur de s�lectionner un
		// num�ro de film
		System.out.println("Veuillez s�lectionner un film en entrant son num�ro");
		int numero = Saisie.entier();
		// On v�rifie que le num�ro est correct
		while (!(numero > 0 && numero < cpt))
		{
			System.out.println("Il faut choisir un num�ro parmi ceux propos�s !");
			numero = Saisie.entier();
		}
		String nomFilmAsked = null;
		// On recherche le film qui est le num�ro N
		// demand� par l'utilisateur
		// On place le curseur � la position N
		OutilsJDBC.clear();
		monResultat4.absolute(numero);
		String titreFilm = monResultat4.getString(1);
		// On cr�e une requete pour aller chercher le
		// num�ro du films correspondant
		String maRequete5 = "SELECT F.NUMFILM FROM ENS2004.INDIVIDU I, ENS2004.FILM F, "
		                    + "ENS2004.ACTEUR A WHERE I.NUMINDIVIDU=A.NUMINDIVIDU "
		                    + "AND F.NUMFILM = A.NUMFILM " + "AND I.NOMINDIVIDU=UPPER('" + nomActeurAsked
		                    + "')" + "AND F.TITRE=UPPER('" + titreFilm + "')";

		System.out.println(maRequete5);
		// On envoie la requ�te
		ResultSet monResultat5 = OutilsJDBC.exec1Requete(maRequete5, co, 0);
		// On affiche le r�sultat G�n�ral
		OutilsJDBC.clear();
		System.out.println("-------------------------------------");
		System.out.println("SELECTION");
		System.out.println("-------------------------------------");
		System.out.println("Choix de l'acteur : " + nomActeurAsked);
		System.out.println("Choix du film : " + titreFilm);
		System.out.println("-------------------------------------");
		System.out.print("Le num�ro du film est le ");
		OutilsJDBC.afficherTout(monResultat5);
		System.out.println();
		System.out.println("A bient�t sur notre site ! :p");

	}
	// **************************************************
	// TP2
	// **************************************************
	// Question 1
	// Permet de demander une table et d'afficher les caract�ristiques
	// De celle-ci (Attributs, types, etc...)
	public static void question2_1(Connection co) throws InterruptedException, IOException, SQLException
	{
		// On efface la console
		OutilsJDBC.clear();
		// On demande la table
		System.out.println("Quelle est la table dont vous voulez les infos ?");
		// On attend la saisie de la table
		String t = Saisie.chaine();
		// On affiche la question � l'�cran
		OutilsJDBC.afficherQuestion(2, 1);
		// Requete pour r�cup�rer la table demand�e
		String requete = "SELECT * FROM ENS2004." + t;
		// On envoie la requ�te au serveur
		ResultSet res = OutilsJDBC.exec1Requete(requete, co, 0);
		// On clean la console
		OutilsJDBC.clear();
		// On affiche le r�sultat
		OutilsJDBC.afficherInfosTable(res);
	}
	// Question 2
	// Permet de savoir la liste des films jou�s par un acteur dont le nom est demand�
	// On affiche tous les acteurs portant le nom
	// On utilise un PS pour cette question
	public static void question2_2(Connection co) throws InterruptedException, IOException, SQLException
	{
		// On efface la console
		OutilsJDBC.clear();
		// Affichage de la question
		OutilsJDBC.afficherQuestion(2, 2);
		// Requete, retourne tous les individus portant ce nom
		String requete = "SELECT * FROM ens2004.INDIVIDU WHERE NOMINDIVIDU = ?";
		// On cr�e l'objet PS
		PreparedStatement prepare = co.prepareStatement(requete, ResultSet.TYPE_SCROLL_INSENSITIVE,
		                    ResultSet.CONCUR_READ_ONLY);
		// Demande du nom de l'acteur
		System.out.println("Entrez votre nom d'acteur");
		// On stocke l'acteur
		String acteur = Saisie.chaine();
		// On up l'acteur
		acteur = acteur.toUpperCase();
		// On pr�cise l'argument du PS
		prepare.setString(1, acteur);
		// On ex�cute le PS
		ResultSet rs = prepare.executeQuery();
		// clear de la console
		OutilsJDBC.clear();
		// On v�rifie qu'il y a au moins un r�sultat
		if (!rs.next())
		{
			System.out.println("Il n'y a pas d'acteur portant ce nom");
		}
		else
		{
			rs.previous();
			// On affiche tous les r�sultats
			// Tant que le PS a des r�sutlats ...
			// Compteur pour l'affichage
			int i = 1;
			while (rs.next())
			{
				// On stocke les nom et les pr�noms retourn�s
				String nom = rs.getString("NOMINDIVIDU");
				String prenom = rs.getString("PRENOMINDIVIDU");
				// Affichage de l'acteur
				System.out.println("#####################################");
				System.out.println(i + ". " + prenom + " " + nom);
				System.out.println("-------------------------------------");
				// Requete pour r�cup�rer tous les films de CET acteur
				String requete2 = "SELECT Titre FROM ens2004.FILM fi, ens2004.INDIVIDU ind, ens2004.ACTEUR ac "
				                    + "WHERE fi.NUMFILM = ac.NUMFILM "
				                    + "AND ac.NUMINDIVIDU = IND.NUMINDIVIDU "
				                    + "AND NOMINDIVIDU = '" + nom + "'"
				                    + "AND PRENOMINDIVIDU = '" + prenom + "'";
				// On envoie la requete
				ResultSet res = OutilsJDBC.exec1Requete(requete2, co, 0);
				// On affiche le r�sultat de la requete
				OutilsJDBC.afficherTout(res);
				// cpt ++
				i++;
			}
		}
	}
	// Question 3
	// Retourne le nombre de films jou�s par un acteur � l'aide d'une fonction PL/SQL
	public static void question2_3(Connection co) throws InterruptedException, IOException, SQLException
	{
		// Clean 
		OutilsJDBC.clear();
		// Affichage de la question
		OutilsJDBC.afficherQuestion(2, 3);
		// Saisie du nom de l'acteur
		System.out.println("Veuillez saisir votre acteur pr�f�r� ?");
		// Stockage du nom
		String nomActeurAsked = Saisie.chaine().toUpperCase();
		// ON DOIT PRESENTER TOUS LES COUPLES PRENOMS/NOMS QUI ONT CE NOM
		// On recherche tous les pr�noms avec ce nom
		String maRequete1 = "SELECT I.PRENOMINDIVIDU FROM ENS2004.INDIVIDU I WHERE I.NOMINDIVIDU=UPPER('"
		                    + nomActeurAsked + "')";
		// On envoie la requ�te
		ResultSet monResultat1 = OutilsJDBC.exec1Requete(maRequete1, co, 1);
		// On regarde si on a au moins un r�sultat
		if (!monResultat1.next())
		{
			System.out.println("Il n'y a aucun acteur de ce nom dans la Base");
		}
		// On recule le curseur d'un rang vu que next l'a avanc�
		monResultat1.previous();
		// Affichage de tous les couples que l'on a trouv�
		int cpt = 1;
		// On efface l'affichage
		OutilsJDBC.clear();
		while (monResultat1.next())
		{
			System.out.print(cpt + ". ");
			System.out.print(monResultat1.getString(1) + " " + nomActeurAsked.toUpperCase());
			System.out.println();
			cpt++;
		}
		// On demande � l'user de choisir un acteur pr�cis parmi la liste qu'on lui propose
		System.out.println("Veuillez s�lectionner un acteur en entrant son num�ro");
		// Choix de l'acteur
		int numActeurAsked = Saisie.entier();
		// On v�rifie que le num�ro est correct
		while (!(numActeurAsked > 0 && numActeurAsked < cpt))
		{
			System.out.println("Il faut choisir un num�ro parmi ceux propos�s !");
			numActeurAsked = Saisie.entier();
		}
		// On place le curseur � la position N
		monResultat1.absolute(numActeurAsked);
		// On r�cup�re le pr�nom de l'acteur
		String prenomActeurAscked = monResultat1.getString(1);
		// On r�cup�re le num�ro de cet acteur
		String maRequete2 = "SELECT A.NUMINDIVIDU FROM ENS2004.ACTEUR A, ENS2004.INDIVIDU I WHERE A.NUMINDIVIDU=I.NUMINDIVIDU AND I.NOMINDIVIDU=UPPER('"
		                    + nomActeurAsked + "') AND I.PRENOMINDIVIDU=UPPER('" + prenomActeurAscked
		                    + "')";
		// On envoie la requ�te
		ResultSet monResultat2 = OutilsJDBC.exec1Requete(maRequete2, co, 0);
		// Clean
		OutilsJDBC.clear();
		// On appelle le next 
		if (!monResultat2.next())
		{
			System.out.println("L'acteur " + prenomActeurAscked + " " + nomActeurAsked
			                    + " n'a fait aucun film dans notre base de donn�es");
		}
		else
		{
			// On appelle la fonction stock�e
			CallableStatement cst = co.prepareCall("{? = call nbreFilms1(?)}");
			// On pr�cise les param�tres
			cst.setInt(2, monResultat2.getInt(1));
			cst.registerOutParameter(1, java.sql.Types.INTEGER);
			// On ex�cute la fonction
			cst.execute();
			// Affichage final
			System.out.println("L'acteur " + prenomActeurAscked + " " + nomActeurAsked
			                    + " a tourn� dans " + cst.getString(1) + " films");
			cst.close();
		}
	}
	// Question 4
	// Permet de saisir un nom de r�alisateur et de savoir combien de film il a tourn�
	public static void question2_4(Connection co) throws InterruptedException, IOException, SQLException
	{
		// Clean
		OutilsJDBC.clear();
		// Affichage de la question
		OutilsJDBC.afficherQuestion(2, 4);
		// Saisie du nom de l'acteur
		System.out.println("Veuillez saisir un nom de r�alisateur");
		// Stockage du nom
		String nomReaAsked = Saisie.chaine().toUpperCase();
		// On appelle la fonction stock�e
		CallableStatement cst = co.prepareCall("{? = call nbreFilms2(?)}");
		// On pr�cise les param�tres
		cst.setString(2, nomReaAsked);
		cst.registerOutParameter(1, java.sql.Types.INTEGER);
		// On ex�cute la PL/SQL
		cst.execute();
		// Affichage final
		if (cst.getString(1).equals("0"))
		{
			System.out.println("Cette personne n'a fait aucun film dans notre base");;
		}
		else if (cst.getString(1).equals("1"))
		{
			System.out.println("Le r�alisateur " + nomReaAsked + " a r�alis� " + cst.getString(1)
			                    + " film");
		}
		else
		{
			System.out.println("Le r�alisateur " + nomReaAsked + " a r�alis� " + cst.getString(1)
			                    + " films");
		}
		cst.close();
	}
	// Question 5
	// Retourne un film jou� par l'acteur donn�, dont on ne connait que le nom
	// On donne le premier film trouv� et on pr�cise le pr�nom de l'acteur qui y joue
	public static void question2_5(Connection co) throws InterruptedException, IOException, SQLException
	{
		// Clean
		OutilsJDBC.clear();
		// Affichage de la question
		OutilsJDBC.afficherQuestion(2, 5);
		// Saisie du nom de l'acteur
		System.out.println("Veuillez saisir votre acteur pr�f�r�, nous allons rechercher un film...");
		// Stockage du nom
		String nomActeurAsked = Saisie.chaine().toUpperCase();
		// Variables
		String titre;
		String prenom;
		// On appelle la fonction stock�e
		CallableStatement cst = co.prepareCall("{call unTitre(?,?,?)}");
		// On pr�cise les param�tres
		cst.setString(1, nomActeurAsked);
		cst.registerOutParameter(2, java.sql.Types.VARCHAR);
		cst.registerOutParameter(3, java.sql.Types.VARCHAR);
		// On ex�cute la fonction
		cst.execute();
		// resultats
		titre = cst.getString(3);
		prenom = cst.getString(2);
		// Clean
		OutilsJDBC.clear();
		// Affichage final
		if (titre != null)
		{
			System.out.println("Nous avons trouv� le film '" + titre + "' pour l'acteur " + prenom
			                    + " " + nomActeurAsked);
		}
		else
		{
			System.out.println("Il n'y a aucun film pour ce nom d'acteur !");
		}
		// Close
		cst.close();
	}
	// Question 6
	// En indiquant un nom, retourne une com�die de cet acteur
	public static void question2_6(Connection co) throws InterruptedException, IOException, SQLException
	{
		// Clean
		OutilsJDBC.clear();
		// Affichage de la question
		OutilsJDBC.afficherQuestion(2, 6);
		// Saisie du nom de l'acteur
		System.out.println("Entrez un acteur dont vous voulez connaitre une com�die");
		// Stockage du nom
		String nomActeurAsked = Saisie.chaine().toUpperCase();
		// Variables
		String titre;
		String prenom;
		// On appelle la fonction stock�e
		CallableStatement cst = co.prepareCall("{? = call uneComedie(?,?)}");
		// On pr�cise les param�tres
		cst.setString(2, nomActeurAsked);
		cst.registerOutParameter(1, java.sql.Types.VARCHAR);
		cst.registerOutParameter(3, java.sql.Types.VARCHAR);
		// On ex�cute la fonction
		cst.execute();
		// resultats
		titre = cst.getString(1);
		prenom = cst.getString(3);
		// Clean
		OutilsJDBC.clear();
		// Affichage final
		if (titre != null)
		{
			System.out.println("Nous avons trouv� la com�die '" + titre + "' pour l'acteur " + prenom
			                    + " " + nomActeurAsked);
		}
		else
		{
			System.out.println("Il n'y a aucune com�die pour ce nom d'acteur !");
		}
		// Close
		cst.close();
	}
}
