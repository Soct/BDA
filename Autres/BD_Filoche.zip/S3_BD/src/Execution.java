import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
// Classe Execution
// Corentin Filoche
public class Execution
{
	public static void main(String[] args) throws InterruptedException, IOException, SQLException
	{
		boolean again = false;

		if (args.length != 2)
		{
			System.out.println("Vous devez entrer votre ID et votre mdp");
		}
		else
		{
			// On efface la console apr�s la saisie du mdp
			OutilsJDBC.clear();
			// On se connecte � la base de donn�es
			String url = "jdbc:oracle:thin:" + args[0] + "/" + args[1]
			                    + "@oracle.iut-orsay.fr:1521:etudom";
			Connection co = OutilsJDBC.connexion(url);
			do
			{
				// Demande du TP
				System.out.println("Quel exercice voulez-vous ex�cuter ?");
				System.out.println("------------------------------------");
				System.out.println("1. TP1");
				System.out.println("2. TP2");
				int tp = Saisie.entier();
				while (tp < 1 || tp > 2)
				{
					System.out.println("Veuillez saisir un num�ro de TP entre 0 et 2");
				}
				switch (tp)
				{
					case 1 :
						OutilsJDBC.clear();
						// Demande de l'exercice
						System.out.println("Quel exercice voulez-vous ex�cuter ?");
						System.out.println("------------------------------------");
						System.out.println("1. Afficher les 10 premiers films");
						System.out.println("2. Idem");
						System.out.println("3. Afficher les gens qui s'appellent FONDA");
						System.out.println("4. Donner la liste des films de Stephen Roberts");
						System.out.println("5. R�servation Film");

						int exo = Saisie.entier();
						while (exo < 1 || exo > 5)
						{
							System.out.println("Veuillez saisir un num�ro entre 0 et 5");
						}
						switch (exo)
						{
							// **************************************************
							// Question 1
							// **************************************************
							case 1 :
								Question.question1_1(co);
								break;

							// **************************************************
							// Question 2
							// **************************************************
							case 2 :
								Question.question1_2(co);
								break;

							// **************************************************
							// Question 3
							// **************************************************
							case 3 :
								Question.question1_3(co);
								break;

							// **************************************************
							// Question 4
							// **************************************************
							case 4 :

								Question.question1_4(co);
								break;

							// **************************************************
							// Question 5
							// **************************************************
							case 5 :
								Question.question1_5(co);
								break;
							// **************************************************
							// Question 6
							// **************************************************
							case 6 :
								//Question.question1_6(co);
								break;
						}
						System.out.println("Voulez-vous faire autre chose ? (oui/non)");
						String ok = Saisie.chaine();
						if (ok.equals("oui"))
						{
							again = true;
						}
						else if (ok.equals("non"))
						{
							again = false;
						}
						else
						{
							System.out.println("Vous n'avez mis ni oui ni non, je consid�re comme non.");
							System.out.println("Programme termin�");
							again = false;
						}
						break;
					case 2 :
						OutilsJDBC.clear();
						// Demande de l'exercice
						System.out.println("Quel exercice voulez-vous ex�cuter ?");
						System.out.println("------------------------------------");
						System.out.println("1. Infos table");
						System.out.println("2. Liste films acteur - PS");
						System.out.println("3. PL/SQL - Nombre film d'un acteur");
						System.out.println("4. PL/SQL - Nombre film d'un r�alisateur");
						System.out.println("5. Trouver un film d'un acteur");
						System.out.println("6. Trouver une com�die d'un acteur");

						int exo2 = Saisie.entier();
						while (exo2 < 1 || exo2 > 6)
						{
							System.out.println("Veuillez saisir un num�ro entre 0 et 6");
						}
						switch (exo2)
						{
							// **************************************************
							// Question 1
							// **************************************************
							case 1 :
								Question.question2_1(co);
								break;

							// **************************************************
							// Question 2
							// **************************************************
							case 2 :
								Question.question2_2(co);
								break;

							// **************************************************
							// Question 3
							// **************************************************
							case 3 :
								Question.question2_3(co);
								break;

							// **************************************************
							// Question 4
							// **************************************************
							case 4 :

								Question.question2_4(co);
								break;

							// **************************************************
							// Question 5
							// **************************************************
							case 5 :
								Question.question2_5(co);
								break;
							// **************************************************
							// Question 6
							// **************************************************
							case 6 :
								Question.question2_6(co);
								break;
						}
						System.out.println("Voulez-vous faire autre chose ? (oui/non)");
						String ok2 = Saisie.chaine();
						if (ok2.equals("oui"))
						{
							again = true;
						}
						else if (ok2.equals("non"))
						{
							again = false;
						}
						else
						{
							System.out.println("Vous n'avez mis ni oui ni non, je consid�re comme non.");
							System.out.println("Programme termin�");
							again = false;
						}
						break;
				}

				OutilsJDBC.clear();
			}
			while (again);
			OutilsJDBC.closeConnection(co);
		}
	}
}
