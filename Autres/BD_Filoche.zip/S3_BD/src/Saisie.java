import java.io.*;
// Classe Saisie
// Corentin Filoche
// Permet d'attendre la saisie d'un entier ou d'une chaine de caract�re
public class Saisie
{
	// Permet de saisir une chaine de caract�re
	public static String chaine()
	{
		String valeur;
		try
		{
			BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));
			valeur = entree.readLine();
			
			return (valeur);
		}
		catch (IOException e)
		{
			System.out.println("Probleme de lecture");
			return (" ");
		}
	}
	// Permet de saisir un entier
	public static int entier()
	{
		String valeur;
		try
		{
			BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));
			valeur = entree.readLine();
			int ent = Integer.parseInt(valeur, 10);
			return ent;
		}
		catch (IOException e)
		{
			System.out.println("Probleme de lecture");
			return (0);
		}
	}
}
